-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('头条公告信息（主页告示牌图片展示）', '3', '1', 'signBoardTop', 'ga/signBoardTop/index', 1, 0, 'C', '0', '0', 'ga:signBoardTop:list', '#', 'admin', sysdate(), '', null, '头条公告信息（主页告示牌图片展示）菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('头条公告信息（主页告示牌图片展示）查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'ga:signBoardTop:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('头条公告信息（主页告示牌图片展示）新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'ga:signBoardTop:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('头条公告信息（主页告示牌图片展示）修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'ga:signBoardTop:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('头条公告信息（主页告示牌图片展示）删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'ga:signBoardTop:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('头条公告信息（主页告示牌图片展示）导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'ga:signBoardTop:export',       '#', 'admin', sysdate(), '', null, '');