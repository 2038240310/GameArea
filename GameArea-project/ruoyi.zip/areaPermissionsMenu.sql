-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('平台模块权限分配', '3', '1', 'areaPermissions', 'ga/areaPermissions/index', 1, 0, 'C', '0', '0', 'ga:areaPermissions:list', '#', 'admin', sysdate(), '', null, '平台模块权限分配菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('平台模块权限分配查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'ga:areaPermissions:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('平台模块权限分配新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'ga:areaPermissions:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('平台模块权限分配修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'ga:areaPermissions:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('平台模块权限分配删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'ga:areaPermissions:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('平台模块权限分配导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'ga:areaPermissions:export',       '#', 'admin', sysdate(), '', null, '');