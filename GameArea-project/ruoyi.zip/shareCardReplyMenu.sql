-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('分享站帖子回复', '3', '1', 'shareCardReply', 'ga/shareCardReply/index', 1, 0, 'C', '0', '0', 'ga:shareCardReply:list', '#', 'admin', sysdate(), '', null, '分享站帖子回复菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('分享站帖子回复查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'ga:shareCardReply:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('分享站帖子回复新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'ga:shareCardReply:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('分享站帖子回复修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'ga:shareCardReply:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('分享站帖子回复删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'ga:shareCardReply:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('分享站帖子回复导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'ga:shareCardReply:export',       '#', 'admin', sysdate(), '', null, '');