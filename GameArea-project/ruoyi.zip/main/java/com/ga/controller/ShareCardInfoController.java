package com.ga.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ga.domain.ShareCardInfo;
import com.ga.service.IShareCardInfoService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 资源站帖子信息Controller
 * 
 * @author wws
 * @date 2023-04-13
 */
@RestController
@RequestMapping("/ga/shareCardInfo")
public class ShareCardInfoController extends BaseController
{
    @Autowired
    private IShareCardInfoService shareCardInfoService;

    /**
     * 查询资源站帖子信息列表
     */
    @PreAuthorize("@ss.hasPermi('ga:shareCardInfo:list')")
    @GetMapping("/list")
    public TableDataInfo list(ShareCardInfo shareCardInfo)
    {
        startPage();
        List<ShareCardInfo> list = shareCardInfoService.selectShareCardInfoList(shareCardInfo);
        return getDataTable(list);
    }

    /**
     * 导出资源站帖子信息列表
     */
    @PreAuthorize("@ss.hasPermi('ga:shareCardInfo:export')")
    @Log(title = "资源站帖子信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, ShareCardInfo shareCardInfo)
    {
        List<ShareCardInfo> list = shareCardInfoService.selectShareCardInfoList(shareCardInfo);
        ExcelUtil<ShareCardInfo> util = new ExcelUtil<ShareCardInfo>(ShareCardInfo.class);
        util.exportExcel(response, list, "资源站帖子信息数据");
    }

    /**
     * 获取资源站帖子信息详细信息
     */
    @PreAuthorize("@ss.hasPermi('ga:shareCardInfo:query')")
    @GetMapping(value = "/{infoId}")
    public AjaxResult getInfo(@PathVariable("infoId") Long infoId)
    {
        return success(shareCardInfoService.selectShareCardInfoByInfoId(infoId));
    }

    /**
     * 新增资源站帖子信息
     */
    @PreAuthorize("@ss.hasPermi('ga:shareCardInfo:add')")
    @Log(title = "资源站帖子信息", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody ShareCardInfo shareCardInfo)
    {
        return toAjax(shareCardInfoService.insertShareCardInfo(shareCardInfo));
    }

    /**
     * 修改资源站帖子信息
     */
    @PreAuthorize("@ss.hasPermi('ga:shareCardInfo:edit')")
    @Log(title = "资源站帖子信息", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody ShareCardInfo shareCardInfo)
    {
        return toAjax(shareCardInfoService.updateShareCardInfo(shareCardInfo));
    }

    /**
     * 删除资源站帖子信息
     */
    @PreAuthorize("@ss.hasPermi('ga:shareCardInfo:remove')")
    @Log(title = "资源站帖子信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{infoIds}")
    public AjaxResult remove(@PathVariable Long[] infoIds)
    {
        return toAjax(shareCardInfoService.deleteShareCardInfoByInfoIds(infoIds));
    }
}
