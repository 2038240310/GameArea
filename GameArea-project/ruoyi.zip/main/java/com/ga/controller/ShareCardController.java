package com.ga.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ga.domain.ShareCard;
import com.ga.service.IShareCardService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 分享站帖子Controller
 * 
 * @author wws
 * @date 2023-04-13
 */
@RestController
@RequestMapping("/ga/shareCard")
public class ShareCardController extends BaseController
{
    @Autowired
    private IShareCardService shareCardService;

    /**
     * 查询分享站帖子列表
     */
    @PreAuthorize("@ss.hasPermi('ga:shareCard:list')")
    @GetMapping("/list")
    public TableDataInfo list(ShareCard shareCard)
    {
        startPage();
        List<ShareCard> list = shareCardService.selectShareCardList(shareCard);
        return getDataTable(list);
    }

    /**
     * 导出分享站帖子列表
     */
    @PreAuthorize("@ss.hasPermi('ga:shareCard:export')")
    @Log(title = "分享站帖子", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, ShareCard shareCard)
    {
        List<ShareCard> list = shareCardService.selectShareCardList(shareCard);
        ExcelUtil<ShareCard> util = new ExcelUtil<ShareCard>(ShareCard.class);
        util.exportExcel(response, list, "分享站帖子数据");
    }

    /**
     * 获取分享站帖子详细信息
     */
    @PreAuthorize("@ss.hasPermi('ga:shareCard:query')")
    @GetMapping(value = "/{cardId}")
    public AjaxResult getInfo(@PathVariable("cardId") Long cardId)
    {
        return success(shareCardService.selectShareCardByCardId(cardId));
    }

    /**
     * 新增分享站帖子
     */
    @PreAuthorize("@ss.hasPermi('ga:shareCard:add')")
    @Log(title = "分享站帖子", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody ShareCard shareCard)
    {
        return toAjax(shareCardService.insertShareCard(shareCard));
    }

    /**
     * 修改分享站帖子
     */
    @PreAuthorize("@ss.hasPermi('ga:shareCard:edit')")
    @Log(title = "分享站帖子", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody ShareCard shareCard)
    {
        return toAjax(shareCardService.updateShareCard(shareCard));
    }

    /**
     * 删除分享站帖子
     */
    @PreAuthorize("@ss.hasPermi('ga:shareCard:remove')")
    @Log(title = "分享站帖子", businessType = BusinessType.DELETE)
	@DeleteMapping("/{cardIds}")
    public AjaxResult remove(@PathVariable Long[] cardIds)
    {
        return toAjax(shareCardService.deleteShareCardByCardIds(cardIds));
    }
}
