package com.ga.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ga.domain.ShareCardTag;
import com.ga.service.IShareCardTagService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 资源站帖子-标签关联Controller
 * 
 * @author wws
 * @date 2023-04-13
 */
@RestController
@RequestMapping("/ga/shareCardTag")
public class ShareCardTagController extends BaseController
{
    @Autowired
    private IShareCardTagService shareCardTagService;

    /**
     * 查询资源站帖子-标签关联列表
     */
    @PreAuthorize("@ss.hasPermi('ga:shareCardTag:list')")
    @GetMapping("/list")
    public TableDataInfo list(ShareCardTag shareCardTag)
    {
        startPage();
        List<ShareCardTag> list = shareCardTagService.selectShareCardTagList(shareCardTag);
        return getDataTable(list);
    }

    /**
     * 导出资源站帖子-标签关联列表
     */
    @PreAuthorize("@ss.hasPermi('ga:shareCardTag:export')")
    @Log(title = "资源站帖子-标签关联", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, ShareCardTag shareCardTag)
    {
        List<ShareCardTag> list = shareCardTagService.selectShareCardTagList(shareCardTag);
        ExcelUtil<ShareCardTag> util = new ExcelUtil<ShareCardTag>(ShareCardTag.class);
        util.exportExcel(response, list, "资源站帖子-标签关联数据");
    }

    /**
     * 获取资源站帖子-标签关联详细信息
     */
    @PreAuthorize("@ss.hasPermi('ga:shareCardTag:query')")
    @GetMapping(value = "/{relId}")
    public AjaxResult getInfo(@PathVariable("relId") Long relId)
    {
        return success(shareCardTagService.selectShareCardTagByRelId(relId));
    }

    /**
     * 新增资源站帖子-标签关联
     */
    @PreAuthorize("@ss.hasPermi('ga:shareCardTag:add')")
    @Log(title = "资源站帖子-标签关联", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody ShareCardTag shareCardTag)
    {
        return toAjax(shareCardTagService.insertShareCardTag(shareCardTag));
    }

    /**
     * 修改资源站帖子-标签关联
     */
    @PreAuthorize("@ss.hasPermi('ga:shareCardTag:edit')")
    @Log(title = "资源站帖子-标签关联", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody ShareCardTag shareCardTag)
    {
        return toAjax(shareCardTagService.updateShareCardTag(shareCardTag));
    }

    /**
     * 删除资源站帖子-标签关联
     */
    @PreAuthorize("@ss.hasPermi('ga:shareCardTag:remove')")
    @Log(title = "资源站帖子-标签关联", businessType = BusinessType.DELETE)
	@DeleteMapping("/{relIds}")
    public AjaxResult remove(@PathVariable Long[] relIds)
    {
        return toAjax(shareCardTagService.deleteShareCardTagByRelIds(relIds));
    }
}
