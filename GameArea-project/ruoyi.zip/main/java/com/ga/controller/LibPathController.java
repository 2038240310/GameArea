package com.ga.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ga.domain.LibPath;
import com.ga.service.ILibPathService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 资料库资源路径Controller
 * 
 * @author wws
 * @date 2023-04-13
 */
@RestController
@RequestMapping("/ga/libPath")
public class LibPathController extends BaseController
{
    @Autowired
    private ILibPathService libPathService;

    /**
     * 查询资料库资源路径列表
     */
    @PreAuthorize("@ss.hasPermi('ga:libPath:list')")
    @GetMapping("/list")
    public TableDataInfo list(LibPath libPath)
    {
        startPage();
        List<LibPath> list = libPathService.selectLibPathList(libPath);
        return getDataTable(list);
    }

    /**
     * 导出资料库资源路径列表
     */
    @PreAuthorize("@ss.hasPermi('ga:libPath:export')")
    @Log(title = "资料库资源路径", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, LibPath libPath)
    {
        List<LibPath> list = libPathService.selectLibPathList(libPath);
        ExcelUtil<LibPath> util = new ExcelUtil<LibPath>(LibPath.class);
        util.exportExcel(response, list, "资料库资源路径数据");
    }

    /**
     * 获取资料库资源路径详细信息
     */
    @PreAuthorize("@ss.hasPermi('ga:libPath:query')")
    @GetMapping(value = "/{pathId}")
    public AjaxResult getInfo(@PathVariable("pathId") Long pathId)
    {
        return success(libPathService.selectLibPathByPathId(pathId));
    }

    /**
     * 新增资料库资源路径
     */
    @PreAuthorize("@ss.hasPermi('ga:libPath:add')")
    @Log(title = "资料库资源路径", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody LibPath libPath)
    {
        return toAjax(libPathService.insertLibPath(libPath));
    }

    /**
     * 修改资料库资源路径
     */
    @PreAuthorize("@ss.hasPermi('ga:libPath:edit')")
    @Log(title = "资料库资源路径", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody LibPath libPath)
    {
        return toAjax(libPathService.updateLibPath(libPath));
    }

    /**
     * 删除资料库资源路径
     */
    @PreAuthorize("@ss.hasPermi('ga:libPath:remove')")
    @Log(title = "资料库资源路径", businessType = BusinessType.DELETE)
	@DeleteMapping("/{pathIds}")
    public AjaxResult remove(@PathVariable Long[] pathIds)
    {
        return toAjax(libPathService.deleteLibPathByPathIds(pathIds));
    }
}
