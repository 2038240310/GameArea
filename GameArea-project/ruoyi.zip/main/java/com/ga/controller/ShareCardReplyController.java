package com.ga.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ga.domain.ShareCardReply;
import com.ga.service.IShareCardReplyService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 分享站帖子回复Controller
 * 
 * @author wws
 * @date 2023-04-13
 */
@RestController
@RequestMapping("/ga/shareCardReply")
public class ShareCardReplyController extends BaseController
{
    @Autowired
    private IShareCardReplyService shareCardReplyService;

    /**
     * 查询分享站帖子回复列表
     */
    @PreAuthorize("@ss.hasPermi('ga:shareCardReply:list')")
    @GetMapping("/list")
    public TableDataInfo list(ShareCardReply shareCardReply)
    {
        startPage();
        List<ShareCardReply> list = shareCardReplyService.selectShareCardReplyList(shareCardReply);
        return getDataTable(list);
    }

    /**
     * 导出分享站帖子回复列表
     */
    @PreAuthorize("@ss.hasPermi('ga:shareCardReply:export')")
    @Log(title = "分享站帖子回复", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, ShareCardReply shareCardReply)
    {
        List<ShareCardReply> list = shareCardReplyService.selectShareCardReplyList(shareCardReply);
        ExcelUtil<ShareCardReply> util = new ExcelUtil<ShareCardReply>(ShareCardReply.class);
        util.exportExcel(response, list, "分享站帖子回复数据");
    }

    /**
     * 获取分享站帖子回复详细信息
     */
    @PreAuthorize("@ss.hasPermi('ga:shareCardReply:query')")
    @GetMapping(value = "/{replyId}")
    public AjaxResult getInfo(@PathVariable("replyId") Long replyId)
    {
        return success(shareCardReplyService.selectShareCardReplyByReplyId(replyId));
    }

    /**
     * 新增分享站帖子回复
     */
    @PreAuthorize("@ss.hasPermi('ga:shareCardReply:add')")
    @Log(title = "分享站帖子回复", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody ShareCardReply shareCardReply)
    {
        return toAjax(shareCardReplyService.insertShareCardReply(shareCardReply));
    }

    /**
     * 修改分享站帖子回复
     */
    @PreAuthorize("@ss.hasPermi('ga:shareCardReply:edit')")
    @Log(title = "分享站帖子回复", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody ShareCardReply shareCardReply)
    {
        return toAjax(shareCardReplyService.updateShareCardReply(shareCardReply));
    }

    /**
     * 删除分享站帖子回复
     */
    @PreAuthorize("@ss.hasPermi('ga:shareCardReply:remove')")
    @Log(title = "分享站帖子回复", businessType = BusinessType.DELETE)
	@DeleteMapping("/{replyIds}")
    public AjaxResult remove(@PathVariable Long[] replyIds)
    {
        return toAjax(shareCardReplyService.deleteShareCardReplyByReplyIds(replyIds));
    }
}
