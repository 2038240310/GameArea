package com.ga.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ga.domain.AreaModelPermissions;
import com.ga.service.IAreaModelPermissionsService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 平台模块权限分配Controller
 * 
 * @author wws
 * @date 2023-04-13
 */
@RestController
@RequestMapping("/ga/areaPermissions")
public class AreaModelPermissionsController extends BaseController
{
    @Autowired
    private IAreaModelPermissionsService areaModelPermissionsService;

    /**
     * 查询平台模块权限分配列表
     */
    @PreAuthorize("@ss.hasPermi('ga:areaPermissions:list')")
    @GetMapping("/list")
    public TableDataInfo list(AreaModelPermissions areaModelPermissions)
    {
        startPage();
        List<AreaModelPermissions> list = areaModelPermissionsService.selectAreaModelPermissionsList(areaModelPermissions);
        return getDataTable(list);
    }

    /**
     * 导出平台模块权限分配列表
     */
    @PreAuthorize("@ss.hasPermi('ga:areaPermissions:export')")
    @Log(title = "平台模块权限分配", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, AreaModelPermissions areaModelPermissions)
    {
        List<AreaModelPermissions> list = areaModelPermissionsService.selectAreaModelPermissionsList(areaModelPermissions);
        ExcelUtil<AreaModelPermissions> util = new ExcelUtil<AreaModelPermissions>(AreaModelPermissions.class);
        util.exportExcel(response, list, "平台模块权限分配数据");
    }

    /**
     * 获取平台模块权限分配详细信息
     */
    @PreAuthorize("@ss.hasPermi('ga:areaPermissions:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(areaModelPermissionsService.selectAreaModelPermissionsById(id));
    }

    /**
     * 新增平台模块权限分配
     */
    @PreAuthorize("@ss.hasPermi('ga:areaPermissions:add')")
    @Log(title = "平台模块权限分配", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody AreaModelPermissions areaModelPermissions)
    {
        return toAjax(areaModelPermissionsService.insertAreaModelPermissions(areaModelPermissions));
    }

    /**
     * 修改平台模块权限分配
     */
    @PreAuthorize("@ss.hasPermi('ga:areaPermissions:edit')")
    @Log(title = "平台模块权限分配", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody AreaModelPermissions areaModelPermissions)
    {
        return toAjax(areaModelPermissionsService.updateAreaModelPermissions(areaModelPermissions));
    }

    /**
     * 删除平台模块权限分配
     */
    @PreAuthorize("@ss.hasPermi('ga:areaPermissions:remove')")
    @Log(title = "平台模块权限分配", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(areaModelPermissionsService.deleteAreaModelPermissionsByIds(ids));
    }
}
