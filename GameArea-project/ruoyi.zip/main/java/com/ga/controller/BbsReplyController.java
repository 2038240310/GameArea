package com.ga.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ga.domain.BbsReply;
import com.ga.service.IBbsReplyService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 论坛帖子回复信息Controller
 * 
 * @author wws
 * @date 2023-04-13
 */
@RestController
@RequestMapping("/ga/bbsReply")
public class BbsReplyController extends BaseController
{
    @Autowired
    private IBbsReplyService bbsReplyService;

    /**
     * 查询论坛帖子回复信息列表
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsReply:list')")
    @GetMapping("/list")
    public TableDataInfo list(BbsReply bbsReply)
    {
        startPage();
        List<BbsReply> list = bbsReplyService.selectBbsReplyList(bbsReply);
        return getDataTable(list);
    }

    /**
     * 导出论坛帖子回复信息列表
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsReply:export')")
    @Log(title = "论坛帖子回复信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, BbsReply bbsReply)
    {
        List<BbsReply> list = bbsReplyService.selectBbsReplyList(bbsReply);
        ExcelUtil<BbsReply> util = new ExcelUtil<BbsReply>(BbsReply.class);
        util.exportExcel(response, list, "论坛帖子回复信息数据");
    }

    /**
     * 获取论坛帖子回复信息详细信息
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsReply:query')")
    @GetMapping(value = "/{replyId}")
    public AjaxResult getInfo(@PathVariable("replyId") Long replyId)
    {
        return success(bbsReplyService.selectBbsReplyByReplyId(replyId));
    }

    /**
     * 新增论坛帖子回复信息
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsReply:add')")
    @Log(title = "论坛帖子回复信息", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody BbsReply bbsReply)
    {
        return toAjax(bbsReplyService.insertBbsReply(bbsReply));
    }

    /**
     * 修改论坛帖子回复信息
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsReply:edit')")
    @Log(title = "论坛帖子回复信息", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody BbsReply bbsReply)
    {
        return toAjax(bbsReplyService.updateBbsReply(bbsReply));
    }

    /**
     * 删除论坛帖子回复信息
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsReply:remove')")
    @Log(title = "论坛帖子回复信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{replyIds}")
    public AjaxResult remove(@PathVariable Long[] replyIds)
    {
        return toAjax(bbsReplyService.deleteBbsReplyByReplyIds(replyIds));
    }
}
