package com.ga.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ga.domain.AreaUser;
import com.ga.service.IAreaUserService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 平台用户Controller
 * 
 * @author wws
 * @date 2023-04-13
 */
@RestController
@RequestMapping("/ga/areaUser")
public class AreaUserController extends BaseController
{
    @Autowired
    private IAreaUserService areaUserService;

    /**
     * 查询平台用户列表
     */
    @PreAuthorize("@ss.hasPermi('ga:areaUser:list')")
    @GetMapping("/list")
    public TableDataInfo list(AreaUser areaUser)
    {
        startPage();
        List<AreaUser> list = areaUserService.selectAreaUserList(areaUser);
        return getDataTable(list);
    }

    /**
     * 导出平台用户列表
     */
    @PreAuthorize("@ss.hasPermi('ga:areaUser:export')")
    @Log(title = "平台用户", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, AreaUser areaUser)
    {
        List<AreaUser> list = areaUserService.selectAreaUserList(areaUser);
        ExcelUtil<AreaUser> util = new ExcelUtil<AreaUser>(AreaUser.class);
        util.exportExcel(response, list, "平台用户数据");
    }

    /**
     * 获取平台用户详细信息
     */
    @PreAuthorize("@ss.hasPermi('ga:areaUser:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(areaUserService.selectAreaUserById(id));
    }

    /**
     * 新增平台用户
     */
    @PreAuthorize("@ss.hasPermi('ga:areaUser:add')")
    @Log(title = "平台用户", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody AreaUser areaUser)
    {
        return toAjax(areaUserService.insertAreaUser(areaUser));
    }

    /**
     * 修改平台用户
     */
    @PreAuthorize("@ss.hasPermi('ga:areaUser:edit')")
    @Log(title = "平台用户", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody AreaUser areaUser)
    {
        return toAjax(areaUserService.updateAreaUser(areaUser));
    }

    /**
     * 删除平台用户
     */
    @PreAuthorize("@ss.hasPermi('ga:areaUser:remove')")
    @Log(title = "平台用户", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(areaUserService.deleteAreaUserByIds(ids));
    }
}
