package com.ga.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ga.domain.BbsCardInfo;
import com.ga.service.IBbsCardInfoService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 论坛帖子信息Controller
 * 
 * @author wws
 * @date 2023-04-13
 */
@RestController
@RequestMapping("/ga/bbsCardInfo")
public class BbsCardInfoController extends BaseController
{
    @Autowired
    private IBbsCardInfoService bbsCardInfoService;

    /**
     * 查询论坛帖子信息列表
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsCardInfo:list')")
    @GetMapping("/list")
    public TableDataInfo list(BbsCardInfo bbsCardInfo)
    {
        startPage();
        List<BbsCardInfo> list = bbsCardInfoService.selectBbsCardInfoList(bbsCardInfo);
        return getDataTable(list);
    }

    /**
     * 导出论坛帖子信息列表
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsCardInfo:export')")
    @Log(title = "论坛帖子信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, BbsCardInfo bbsCardInfo)
    {
        List<BbsCardInfo> list = bbsCardInfoService.selectBbsCardInfoList(bbsCardInfo);
        ExcelUtil<BbsCardInfo> util = new ExcelUtil<BbsCardInfo>(BbsCardInfo.class);
        util.exportExcel(response, list, "论坛帖子信息数据");
    }

    /**
     * 获取论坛帖子信息详细信息
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsCardInfo:query')")
    @GetMapping(value = "/{infoId}")
    public AjaxResult getInfo(@PathVariable("infoId") Long infoId)
    {
        return success(bbsCardInfoService.selectBbsCardInfoByInfoId(infoId));
    }

    /**
     * 新增论坛帖子信息
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsCardInfo:add')")
    @Log(title = "论坛帖子信息", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody BbsCardInfo bbsCardInfo)
    {
        return toAjax(bbsCardInfoService.insertBbsCardInfo(bbsCardInfo));
    }

    /**
     * 修改论坛帖子信息
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsCardInfo:edit')")
    @Log(title = "论坛帖子信息", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody BbsCardInfo bbsCardInfo)
    {
        return toAjax(bbsCardInfoService.updateBbsCardInfo(bbsCardInfo));
    }

    /**
     * 删除论坛帖子信息
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsCardInfo:remove')")
    @Log(title = "论坛帖子信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{infoIds}")
    public AjaxResult remove(@PathVariable Long[] infoIds)
    {
        return toAjax(bbsCardInfoService.deleteBbsCardInfoByInfoIds(infoIds));
    }
}
