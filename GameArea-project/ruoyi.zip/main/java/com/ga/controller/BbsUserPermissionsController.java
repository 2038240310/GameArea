package com.ga.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ga.domain.BbsUserPermissions;
import com.ga.service.IBbsUserPermissionsService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 帖子用户权限配置Controller
 * 
 * @author wws
 * @date 2023-04-13
 */
@RestController
@RequestMapping("/ga/bbsUserPermissions")
public class BbsUserPermissionsController extends BaseController
{
    @Autowired
    private IBbsUserPermissionsService bbsUserPermissionsService;

    /**
     * 查询帖子用户权限配置列表
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsUserPermissions:list')")
    @GetMapping("/list")
    public TableDataInfo list(BbsUserPermissions bbsUserPermissions)
    {
        startPage();
        List<BbsUserPermissions> list = bbsUserPermissionsService.selectBbsUserPermissionsList(bbsUserPermissions);
        return getDataTable(list);
    }

    /**
     * 导出帖子用户权限配置列表
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsUserPermissions:export')")
    @Log(title = "帖子用户权限配置", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, BbsUserPermissions bbsUserPermissions)
    {
        List<BbsUserPermissions> list = bbsUserPermissionsService.selectBbsUserPermissionsList(bbsUserPermissions);
        ExcelUtil<BbsUserPermissions> util = new ExcelUtil<BbsUserPermissions>(BbsUserPermissions.class);
        util.exportExcel(response, list, "帖子用户权限配置数据");
    }

    /**
     * 获取帖子用户权限配置详细信息
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsUserPermissions:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(bbsUserPermissionsService.selectBbsUserPermissionsById(id));
    }

    /**
     * 新增帖子用户权限配置
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsUserPermissions:add')")
    @Log(title = "帖子用户权限配置", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody BbsUserPermissions bbsUserPermissions)
    {
        return toAjax(bbsUserPermissionsService.insertBbsUserPermissions(bbsUserPermissions));
    }

    /**
     * 修改帖子用户权限配置
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsUserPermissions:edit')")
    @Log(title = "帖子用户权限配置", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody BbsUserPermissions bbsUserPermissions)
    {
        return toAjax(bbsUserPermissionsService.updateBbsUserPermissions(bbsUserPermissions));
    }

    /**
     * 删除帖子用户权限配置
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsUserPermissions:remove')")
    @Log(title = "帖子用户权限配置", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(bbsUserPermissionsService.deleteBbsUserPermissionsByIds(ids));
    }
}
