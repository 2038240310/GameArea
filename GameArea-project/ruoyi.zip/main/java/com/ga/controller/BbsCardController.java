package com.ga.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ga.domain.BbsCard;
import com.ga.service.IBbsCardService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 论坛帖子Controller
 * 
 * @author wws
 * @date 2023-04-13
 */
@RestController
@RequestMapping("/ga/bbsCard")
public class BbsCardController extends BaseController
{
    @Autowired
    private IBbsCardService bbsCardService;

    /**
     * 查询论坛帖子列表
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsCard:list')")
    @GetMapping("/list")
    public TableDataInfo list(BbsCard bbsCard)
    {
        startPage();
        List<BbsCard> list = bbsCardService.selectBbsCardList(bbsCard);
        return getDataTable(list);
    }

    /**
     * 导出论坛帖子列表
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsCard:export')")
    @Log(title = "论坛帖子", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, BbsCard bbsCard)
    {
        List<BbsCard> list = bbsCardService.selectBbsCardList(bbsCard);
        ExcelUtil<BbsCard> util = new ExcelUtil<BbsCard>(BbsCard.class);
        util.exportExcel(response, list, "论坛帖子数据");
    }

    /**
     * 获取论坛帖子详细信息
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsCard:query')")
    @GetMapping(value = "/{cardId}")
    public AjaxResult getInfo(@PathVariable("cardId") Long cardId)
    {
        return success(bbsCardService.selectBbsCardByCardId(cardId));
    }

    /**
     * 新增论坛帖子
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsCard:add')")
    @Log(title = "论坛帖子", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody BbsCard bbsCard)
    {
        return toAjax(bbsCardService.insertBbsCard(bbsCard));
    }

    /**
     * 修改论坛帖子
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsCard:edit')")
    @Log(title = "论坛帖子", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody BbsCard bbsCard)
    {
        return toAjax(bbsCardService.updateBbsCard(bbsCard));
    }

    /**
     * 删除论坛帖子
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsCard:remove')")
    @Log(title = "论坛帖子", businessType = BusinessType.DELETE)
	@DeleteMapping("/{cardIds}")
    public AjaxResult remove(@PathVariable Long[] cardIds)
    {
        return toAjax(bbsCardService.deleteBbsCardByCardIds(cardIds));
    }
}
