package com.ga.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ga.domain.BbsReplyReply;
import com.ga.service.IBbsReplyReplyService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 论坛帖子二级回复消息Controller
 * 
 * @author wws
 * @date 2023-04-13
 */
@RestController
@RequestMapping("/ga/bbsReplyReply")
public class BbsReplyReplyController extends BaseController
{
    @Autowired
    private IBbsReplyReplyService bbsReplyReplyService;

    /**
     * 查询论坛帖子二级回复消息列表
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsReplyReply:list')")
    @GetMapping("/list")
    public TableDataInfo list(BbsReplyReply bbsReplyReply)
    {
        startPage();
        List<BbsReplyReply> list = bbsReplyReplyService.selectBbsReplyReplyList(bbsReplyReply);
        return getDataTable(list);
    }

    /**
     * 导出论坛帖子二级回复消息列表
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsReplyReply:export')")
    @Log(title = "论坛帖子二级回复消息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, BbsReplyReply bbsReplyReply)
    {
        List<BbsReplyReply> list = bbsReplyReplyService.selectBbsReplyReplyList(bbsReplyReply);
        ExcelUtil<BbsReplyReply> util = new ExcelUtil<BbsReplyReply>(BbsReplyReply.class);
        util.exportExcel(response, list, "论坛帖子二级回复消息数据");
    }

    /**
     * 获取论坛帖子二级回复消息详细信息
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsReplyReply:query')")
    @GetMapping(value = "/{rrId}")
    public AjaxResult getInfo(@PathVariable("rrId") Long rrId)
    {
        return success(bbsReplyReplyService.selectBbsReplyReplyByRrId(rrId));
    }

    /**
     * 新增论坛帖子二级回复消息
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsReplyReply:add')")
    @Log(title = "论坛帖子二级回复消息", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody BbsReplyReply bbsReplyReply)
    {
        return toAjax(bbsReplyReplyService.insertBbsReplyReply(bbsReplyReply));
    }

    /**
     * 修改论坛帖子二级回复消息
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsReplyReply:edit')")
    @Log(title = "论坛帖子二级回复消息", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody BbsReplyReply bbsReplyReply)
    {
        return toAjax(bbsReplyReplyService.updateBbsReplyReply(bbsReplyReply));
    }

    /**
     * 删除论坛帖子二级回复消息
     */
    @PreAuthorize("@ss.hasPermi('ga:bbsReplyReply:remove')")
    @Log(title = "论坛帖子二级回复消息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{rrIds}")
    public AjaxResult remove(@PathVariable Long[] rrIds)
    {
        return toAjax(bbsReplyReplyService.deleteBbsReplyReplyByRrIds(rrIds));
    }
}
