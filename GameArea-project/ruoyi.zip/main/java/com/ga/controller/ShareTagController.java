package com.ga.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ga.domain.ShareTag;
import com.ga.service.IShareTagService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 分享站标签管理Controller
 * 
 * @author wws
 * @date 2023-04-13
 */
@RestController
@RequestMapping("/ga/shareTag")
public class ShareTagController extends BaseController
{
    @Autowired
    private IShareTagService shareTagService;

    /**
     * 查询分享站标签管理列表
     */
    @PreAuthorize("@ss.hasPermi('ga:shareTag:list')")
    @GetMapping("/list")
    public TableDataInfo list(ShareTag shareTag)
    {
        startPage();
        List<ShareTag> list = shareTagService.selectShareTagList(shareTag);
        return getDataTable(list);
    }

    /**
     * 导出分享站标签管理列表
     */
    @PreAuthorize("@ss.hasPermi('ga:shareTag:export')")
    @Log(title = "分享站标签管理", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, ShareTag shareTag)
    {
        List<ShareTag> list = shareTagService.selectShareTagList(shareTag);
        ExcelUtil<ShareTag> util = new ExcelUtil<ShareTag>(ShareTag.class);
        util.exportExcel(response, list, "分享站标签管理数据");
    }

    /**
     * 获取分享站标签管理详细信息
     */
    @PreAuthorize("@ss.hasPermi('ga:shareTag:query')")
    @GetMapping(value = "/{tagId}")
    public AjaxResult getInfo(@PathVariable("tagId") Long tagId)
    {
        return success(shareTagService.selectShareTagByTagId(tagId));
    }

    /**
     * 新增分享站标签管理
     */
    @PreAuthorize("@ss.hasPermi('ga:shareTag:add')")
    @Log(title = "分享站标签管理", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody ShareTag shareTag)
    {
        return toAjax(shareTagService.insertShareTag(shareTag));
    }

    /**
     * 修改分享站标签管理
     */
    @PreAuthorize("@ss.hasPermi('ga:shareTag:edit')")
    @Log(title = "分享站标签管理", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody ShareTag shareTag)
    {
        return toAjax(shareTagService.updateShareTag(shareTag));
    }

    /**
     * 删除分享站标签管理
     */
    @PreAuthorize("@ss.hasPermi('ga:shareTag:remove')")
    @Log(title = "分享站标签管理", businessType = BusinessType.DELETE)
	@DeleteMapping("/{tagIds}")
    public AjaxResult remove(@PathVariable Long[] tagIds)
    {
        return toAjax(shareTagService.deleteShareTagByTagIds(tagIds));
    }
}
