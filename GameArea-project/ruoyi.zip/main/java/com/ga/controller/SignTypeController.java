package com.ga.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ga.domain.SignType;
import com.ga.service.ISignTypeService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 公告版类型管理Controller
 * 
 * @author wws
 * @date 2023-04-13
 */
@RestController
@RequestMapping("/ga/signType")
public class SignTypeController extends BaseController
{
    @Autowired
    private ISignTypeService signTypeService;

    /**
     * 查询公告版类型管理列表
     */
    @PreAuthorize("@ss.hasPermi('ga:signType:list')")
    @GetMapping("/list")
    public TableDataInfo list(SignType signType)
    {
        startPage();
        List<SignType> list = signTypeService.selectSignTypeList(signType);
        return getDataTable(list);
    }

    /**
     * 导出公告版类型管理列表
     */
    @PreAuthorize("@ss.hasPermi('ga:signType:export')")
    @Log(title = "公告版类型管理", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, SignType signType)
    {
        List<SignType> list = signTypeService.selectSignTypeList(signType);
        ExcelUtil<SignType> util = new ExcelUtil<SignType>(SignType.class);
        util.exportExcel(response, list, "公告版类型管理数据");
    }

    /**
     * 获取公告版类型管理详细信息
     */
    @PreAuthorize("@ss.hasPermi('ga:signType:query')")
    @GetMapping(value = "/{typeId}")
    public AjaxResult getInfo(@PathVariable("typeId") Long typeId)
    {
        return success(signTypeService.selectSignTypeByTypeId(typeId));
    }

    /**
     * 新增公告版类型管理
     */
    @PreAuthorize("@ss.hasPermi('ga:signType:add')")
    @Log(title = "公告版类型管理", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody SignType signType)
    {
        return toAjax(signTypeService.insertSignType(signType));
    }

    /**
     * 修改公告版类型管理
     */
    @PreAuthorize("@ss.hasPermi('ga:signType:edit')")
    @Log(title = "公告版类型管理", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody SignType signType)
    {
        return toAjax(signTypeService.updateSignType(signType));
    }

    /**
     * 删除公告版类型管理
     */
    @PreAuthorize("@ss.hasPermi('ga:signType:remove')")
    @Log(title = "公告版类型管理", businessType = BusinessType.DELETE)
	@DeleteMapping("/{typeIds}")
    public AjaxResult remove(@PathVariable Long[] typeIds)
    {
        return toAjax(signTypeService.deleteSignTypeByTypeIds(typeIds));
    }
}
