package com.ga.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ga.domain.SignBoardTop;
import com.ga.service.ISignBoardTopService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 头条公告信息（主页告示牌图片展示）Controller
 * 
 * @author wws
 * @date 2023-04-13
 */
@RestController
@RequestMapping("/ga/signBoardTop")
public class SignBoardTopController extends BaseController
{
    @Autowired
    private ISignBoardTopService signBoardTopService;

    /**
     * 查询头条公告信息（主页告示牌图片展示）列表
     */
    @PreAuthorize("@ss.hasPermi('ga:signBoardTop:list')")
    @GetMapping("/list")
    public TableDataInfo list(SignBoardTop signBoardTop)
    {
        startPage();
        List<SignBoardTop> list = signBoardTopService.selectSignBoardTopList(signBoardTop);
        return getDataTable(list);
    }

    /**
     * 导出头条公告信息（主页告示牌图片展示）列表
     */
    @PreAuthorize("@ss.hasPermi('ga:signBoardTop:export')")
    @Log(title = "头条公告信息（主页告示牌图片展示）", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, SignBoardTop signBoardTop)
    {
        List<SignBoardTop> list = signBoardTopService.selectSignBoardTopList(signBoardTop);
        ExcelUtil<SignBoardTop> util = new ExcelUtil<SignBoardTop>(SignBoardTop.class);
        util.exportExcel(response, list, "头条公告信息（主页告示牌图片展示）数据");
    }

    /**
     * 获取头条公告信息（主页告示牌图片展示）详细信息
     */
    @PreAuthorize("@ss.hasPermi('ga:signBoardTop:query')")
    @GetMapping(value = "/{topIp}")
    public AjaxResult getInfo(@PathVariable("topIp") Long topIp)
    {
        return success(signBoardTopService.selectSignBoardTopByTopIp(topIp));
    }

    /**
     * 新增头条公告信息（主页告示牌图片展示）
     */
    @PreAuthorize("@ss.hasPermi('ga:signBoardTop:add')")
    @Log(title = "头条公告信息（主页告示牌图片展示）", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody SignBoardTop signBoardTop)
    {
        return toAjax(signBoardTopService.insertSignBoardTop(signBoardTop));
    }

    /**
     * 修改头条公告信息（主页告示牌图片展示）
     */
    @PreAuthorize("@ss.hasPermi('ga:signBoardTop:edit')")
    @Log(title = "头条公告信息（主页告示牌图片展示）", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody SignBoardTop signBoardTop)
    {
        return toAjax(signBoardTopService.updateSignBoardTop(signBoardTop));
    }

    /**
     * 删除头条公告信息（主页告示牌图片展示）
     */
    @PreAuthorize("@ss.hasPermi('ga:signBoardTop:remove')")
    @Log(title = "头条公告信息（主页告示牌图片展示）", businessType = BusinessType.DELETE)
	@DeleteMapping("/{topIps}")
    public AjaxResult remove(@PathVariable Long[] topIps)
    {
        return toAjax(signBoardTopService.deleteSignBoardTopByTopIps(topIps));
    }
}
