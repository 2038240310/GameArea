package com.ga.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 资料库操作申请单对象 lib_update_apply
 * 
 * @author wws
 * @date 2023-04-13
 */
public class LibUpdateApply extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** pk */
    private Long id;

    /** 操作类型 （0.修改 1.新增 2.标记错误） */
    @Excel(name = "操作类型 ", readConverterExp = "0=.修改,1=.新增,2=.标记错误")
    private Long applyType;

    /** 申请人id（user_id） */
    @Excel(name = "申请人id", readConverterExp = "u=ser_id")
    private String applicantId;

    /** 状态 (0.未处理 1.已处理 2.不通过) */
    @Excel(name = "状态 (0.未处理 1.已处理 2.不通过)")
    private String status;

    /** 操作对象 */
    @Excel(name = "操作对象")
    private String applyToId;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setApplyType(Long applyType) 
    {
        this.applyType = applyType;
    }

    public Long getApplyType() 
    {
        return applyType;
    }
    public void setApplicantId(String applicantId) 
    {
        this.applicantId = applicantId;
    }

    public String getApplicantId() 
    {
        return applicantId;
    }
    public void setStatus(String status) 
    {
        this.status = status;
    }

    public String getStatus() 
    {
        return status;
    }
    public void setApplyToId(String applyToId) 
    {
        this.applyToId = applyToId;
    }

    public String getApplyToId() 
    {
        return applyToId;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("applyType", getApplyType())
            .append("applicantId", getApplicantId())
            .append("createTime", getCreateTime())
            .append("status", getStatus())
            .append("applyToId", getApplyToId())
            .toString();
    }
}
