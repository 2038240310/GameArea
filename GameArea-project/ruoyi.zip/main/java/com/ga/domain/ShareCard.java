package com.ga.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 分享站帖子对象 share_card
 * 
 * @author wws
 * @date 2023-04-13
 */
public class ShareCard extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** pk */
    private Long cardId;

    /** 分享贴标题 */
    @Excel(name = "分享贴标题")
    private String title;

    /** 分享贴类型id */
    @Excel(name = "分享贴类型id")
    private String typeId;

    /** 状态，0启用，1关闭 */
    @Excel(name = "状态，0启用，1关闭")
    private String status;

    public void setCardId(Long cardId) 
    {
        this.cardId = cardId;
    }

    public Long getCardId() 
    {
        return cardId;
    }
    public void setTitle(String title) 
    {
        this.title = title;
    }

    public String getTitle() 
    {
        return title;
    }
    public void setTypeId(String typeId) 
    {
        this.typeId = typeId;
    }

    public String getTypeId() 
    {
        return typeId;
    }
    public void setStatus(String status) 
    {
        this.status = status;
    }

    public String getStatus() 
    {
        return status;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("cardId", getCardId())
            .append("title", getTitle())
            .append("typeId", getTypeId())
            .append("createBy", getCreateBy())
            .append("createTime", getCreateTime())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .append("status", getStatus())
            .toString();
    }
}
