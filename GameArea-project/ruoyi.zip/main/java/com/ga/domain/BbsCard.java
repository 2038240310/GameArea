package com.ga.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 论坛帖子对象 bbs_card
 * 
 * @author wws
 * @date 2023-04-13
 */
public class BbsCard extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** pk */
    private Long cardId;

    /** 帖子标题 */
    @Excel(name = "帖子标题")
    private String title;

    /** 发帖简述 */
    @Excel(name = "发帖简述")
    private String message;

    /** 所属板块分类id */
    @Excel(name = "所属板块分类id")
    private String blockId;

    /** 所属区块分类id */
    @Excel(name = "所属区块分类id")
    private String areaId;

    /** 状态，0启用，1封贴，2关闭 */
    @Excel(name = "状态，0启用，1封贴，2关闭")
    private String status;

    public void setCardId(Long cardId) 
    {
        this.cardId = cardId;
    }

    public Long getCardId() 
    {
        return cardId;
    }
    public void setTitle(String title) 
    {
        this.title = title;
    }

    public String getTitle() 
    {
        return title;
    }
    public void setMessage(String message) 
    {
        this.message = message;
    }

    public String getMessage() 
    {
        return message;
    }
    public void setBlockId(String blockId) 
    {
        this.blockId = blockId;
    }

    public String getBlockId() 
    {
        return blockId;
    }
    public void setAreaId(String areaId) 
    {
        this.areaId = areaId;
    }

    public String getAreaId() 
    {
        return areaId;
    }
    public void setStatus(String status) 
    {
        this.status = status;
    }

    public String getStatus() 
    {
        return status;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("cardId", getCardId())
            .append("title", getTitle())
            .append("message", getMessage())
            .append("createBy", getCreateBy())
            .append("blockId", getBlockId())
            .append("areaId", getAreaId())
            .append("createTime", getCreateTime())
            .append("updateTime", getUpdateTime())
            .append("status", getStatus())
            .toString();
    }
}
