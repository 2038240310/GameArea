package com.ga.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 公告版信息对象 sign_board
 * 
 * @author wws
 * @date 2023-04-13
 */
public class SignBoard extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** pk */
    private Long boardId;

    /** 公告信息 */
    @Excel(name = "公告信息")
    private String message;

    /** 公告分类id */
    @Excel(name = "公告分类id")
    private String boardType;

    /** 所属区块id */
    @Excel(name = "所属区块id")
    private String areaId;

    /** 导航地址 */
    @Excel(name = "导航地址")
    private String linkPath;

    /** 状态，0启用，1关闭 */
    @Excel(name = "状态，0启用，1关闭")
    private String status;

    public void setBoardId(Long boardId) 
    {
        this.boardId = boardId;
    }

    public Long getBoardId() 
    {
        return boardId;
    }
    public void setMessage(String message) 
    {
        this.message = message;
    }

    public String getMessage() 
    {
        return message;
    }
    public void setBoardType(String boardType) 
    {
        this.boardType = boardType;
    }

    public String getBoardType() 
    {
        return boardType;
    }
    public void setAreaId(String areaId) 
    {
        this.areaId = areaId;
    }

    public String getAreaId() 
    {
        return areaId;
    }
    public void setLinkPath(String linkPath) 
    {
        this.linkPath = linkPath;
    }

    public String getLinkPath() 
    {
        return linkPath;
    }
    public void setStatus(String status) 
    {
        this.status = status;
    }

    public String getStatus() 
    {
        return status;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("boardId", getBoardId())
            .append("message", getMessage())
            .append("boardType", getBoardType())
            .append("areaId", getAreaId())
            .append("linkPath", getLinkPath())
            .append("createBy", getCreateBy())
            .append("createTime", getCreateTime())
            .append("updateTime", getUpdateTime())
            .append("status", getStatus())
            .toString();
    }
}
