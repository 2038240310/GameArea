package com.ga.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 论坛板块对象 bbs_block
 * 
 * @author wws
 * @date 2023-04-13
 */
public class BbsBlock extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** pk */
    private Long blockId;

    /** 板块名称 */
    @Excel(name = "板块名称")
    private String blockName;

    /** 图标路径 */
    @Excel(name = "图标路径")
    private String picPath;

    /** 状态，0启用，1关闭 */
    @Excel(name = "状态，0启用，1关闭")
    private String status;

    public void setBlockId(Long blockId) 
    {
        this.blockId = blockId;
    }

    public Long getBlockId() 
    {
        return blockId;
    }
    public void setBlockName(String blockName) 
    {
        this.blockName = blockName;
    }

    public String getBlockName() 
    {
        return blockName;
    }
    public void setPicPath(String picPath) 
    {
        this.picPath = picPath;
    }

    public String getPicPath() 
    {
        return picPath;
    }
    public void setStatus(String status) 
    {
        this.status = status;
    }

    public String getStatus() 
    {
        return status;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("blockId", getBlockId())
            .append("blockName", getBlockName())
            .append("picPath", getPicPath())
            .append("createTime", getCreateTime())
            .append("updateTime", getUpdateTime())
            .append("status", getStatus())
            .toString();
    }
}
