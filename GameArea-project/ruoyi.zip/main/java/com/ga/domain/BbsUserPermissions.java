package com.ga.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 帖子用户权限配置对象 bbs_user_permissions
 * 
 * @author wws
 * @date 2023-04-13
 */
public class BbsUserPermissions extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** pk */
    private Long id;

    /** 关联帖子板块id */
    @Excel(name = "关联帖子板块id")
    private String blockId;

    /** 关联用户id */
    @Excel(name = "关联用户id")
    private String userId;

    /** 状态 （0.生效中 1.撤销 2.待审核） */
    @Excel(name = "状态 ", readConverterExp = "0=.生效中,1=.撤销,2=.待审核")
    private String status;

    /** 授权人id */
    @Excel(name = "授权人id")
    private String permissionOfferPersonId;

    /** 审核人id */
    @Excel(name = "审核人id")
    private String permissionPassPersonId;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setBlockId(String blockId) 
    {
        this.blockId = blockId;
    }

    public String getBlockId() 
    {
        return blockId;
    }
    public void setUserId(String userId) 
    {
        this.userId = userId;
    }

    public String getUserId() 
    {
        return userId;
    }
    public void setStatus(String status) 
    {
        this.status = status;
    }

    public String getStatus() 
    {
        return status;
    }
    public void setPermissionOfferPersonId(String permissionOfferPersonId) 
    {
        this.permissionOfferPersonId = permissionOfferPersonId;
    }

    public String getPermissionOfferPersonId() 
    {
        return permissionOfferPersonId;
    }
    public void setPermissionPassPersonId(String permissionPassPersonId) 
    {
        this.permissionPassPersonId = permissionPassPersonId;
    }

    public String getPermissionPassPersonId() 
    {
        return permissionPassPersonId;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("blockId", getBlockId())
            .append("userId", getUserId())
            .append("createTime", getCreateTime())
            .append("status", getStatus())
            .append("permissionOfferPersonId", getPermissionOfferPersonId())
            .append("permissionPassPersonId", getPermissionPassPersonId())
            .toString();
    }
}
