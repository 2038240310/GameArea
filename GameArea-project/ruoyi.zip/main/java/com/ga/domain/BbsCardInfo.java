package com.ga.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 论坛帖子信息对象 bbs_card_info
 * 
 * @author wws
 * @date 2023-04-13
 */
public class BbsCardInfo extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** pk */
    private Long infoId;

    /** 相关帖子id */
    @Excel(name = "相关帖子id")
    private String cardId;

    /** 喜欢数量 */
    @Excel(name = "喜欢数量")
    private Long likeNum;

    /** 评论数量 */
    @Excel(name = "评论数量")
    private Long commentNum;

    /** 富文本、图片路径 */
    @Excel(name = "富文本、图片路径")
    private String sourcePath;

    /** 发帖信息内容 */
    @Excel(name = "发帖信息内容")
    private String message;

    public void setInfoId(Long infoId) 
    {
        this.infoId = infoId;
    }

    public Long getInfoId() 
    {
        return infoId;
    }
    public void setCardId(String cardId) 
    {
        this.cardId = cardId;
    }

    public String getCardId() 
    {
        return cardId;
    }
    public void setLikeNum(Long likeNum) 
    {
        this.likeNum = likeNum;
    }

    public Long getLikeNum() 
    {
        return likeNum;
    }
    public void setCommentNum(Long commentNum) 
    {
        this.commentNum = commentNum;
    }

    public Long getCommentNum() 
    {
        return commentNum;
    }
    public void setSourcePath(String sourcePath) 
    {
        this.sourcePath = sourcePath;
    }

    public String getSourcePath() 
    {
        return sourcePath;
    }
    public void setMessage(String message) 
    {
        this.message = message;
    }

    public String getMessage() 
    {
        return message;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("infoId", getInfoId())
            .append("cardId", getCardId())
            .append("likeNum", getLikeNum())
            .append("commentNum", getCommentNum())
            .append("sourcePath", getSourcePath())
            .append("message", getMessage())
            .toString();
    }
}
