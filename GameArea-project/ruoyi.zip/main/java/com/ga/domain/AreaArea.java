package com.ga.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 平台最高级分区对象 area_area
 * 
 * @author wws
 * @date 2023-04-13
 */
public class AreaArea extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** pk */
    private Long id;

    /** 分区域名 */
    @Excel(name = "分区域名")
    private String areaName;

    /** 分区显示图表 */
    @Excel(name = "分区显示图表")
    private String areaPicSource;

    /** 状态 (0.启用 1.关闭 2.弃用) */
    @Excel(name = "状态 (0.启用 1.关闭 2.弃用)")
    private String status;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setAreaName(String areaName) 
    {
        this.areaName = areaName;
    }

    public String getAreaName() 
    {
        return areaName;
    }
    public void setAreaPicSource(String areaPicSource) 
    {
        this.areaPicSource = areaPicSource;
    }

    public String getAreaPicSource() 
    {
        return areaPicSource;
    }
    public void setStatus(String status) 
    {
        this.status = status;
    }

    public String getStatus() 
    {
        return status;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("areaName", getAreaName())
            .append("areaPicSource", getAreaPicSource())
            .append("createTime", getCreateTime())
            .append("status", getStatus())
            .toString();
    }
}
