package com.ga.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 分享站帖子回复对象 share_card_reply
 * 
 * @author wws
 * @date 2023-04-13
 */
public class ShareCardReply extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** pk */
    private Long replyId;

    /** 关联资源帖id */
    @Excel(name = "关联资源帖id")
    private String cardId;

    /** 回复信息文本 */
    @Excel(name = "回复信息文本")
    private String message;

    /** 创建人名称 */
    @Excel(name = "创建人名称")
    private String createName;

    /** 状态，0启用，1关闭 */
    @Excel(name = "状态，0启用，1关闭")
    private String status;

    public void setReplyId(Long replyId) 
    {
        this.replyId = replyId;
    }

    public Long getReplyId() 
    {
        return replyId;
    }
    public void setCardId(String cardId) 
    {
        this.cardId = cardId;
    }

    public String getCardId() 
    {
        return cardId;
    }
    public void setMessage(String message) 
    {
        this.message = message;
    }

    public String getMessage() 
    {
        return message;
    }
    public void setCreateName(String createName) 
    {
        this.createName = createName;
    }

    public String getCreateName() 
    {
        return createName;
    }
    public void setStatus(String status) 
    {
        this.status = status;
    }

    public String getStatus() 
    {
        return status;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("replyId", getReplyId())
            .append("cardId", getCardId())
            .append("message", getMessage())
            .append("createBy", getCreateBy())
            .append("createName", getCreateName())
            .append("createTime", getCreateTime())
            .append("updateTime", getUpdateTime())
            .append("status", getStatus())
            .toString();
    }
}
