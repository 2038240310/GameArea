package com.ga.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 头条公告信息（主页告示牌图片展示）对象 sign_board_top
 * 
 * @author wws
 * @date 2023-04-13
 */
public class SignBoardTop extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** pk */
    private Long topIp;

    /** 相关联公告id */
    @Excel(name = "相关联公告id")
    private String boardId;

    /** 标题 */
    @Excel(name = "标题")
    private String title;

    /** 图片资源路径 */
    @Excel(name = "图片资源路径")
    private String picPath;

    /** 导航路径 */
    @Excel(name = "导航路径")
    private String linkPath;

    public void setTopIp(Long topIp) 
    {
        this.topIp = topIp;
    }

    public Long getTopIp() 
    {
        return topIp;
    }
    public void setBoardId(String boardId) 
    {
        this.boardId = boardId;
    }

    public String getBoardId() 
    {
        return boardId;
    }
    public void setTitle(String title) 
    {
        this.title = title;
    }

    public String getTitle() 
    {
        return title;
    }
    public void setPicPath(String picPath) 
    {
        this.picPath = picPath;
    }

    public String getPicPath() 
    {
        return picPath;
    }
    public void setLinkPath(String linkPath) 
    {
        this.linkPath = linkPath;
    }

    public String getLinkPath() 
    {
        return linkPath;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("topIp", getTopIp())
            .append("boardId", getBoardId())
            .append("title", getTitle())
            .append("picPath", getPicPath())
            .append("linkPath", getLinkPath())
            .toString();
    }
}
