package com.ga.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 资料库资源路径对象 lib_path
 * 
 * @author wws
 * @date 2023-04-13
 */
public class LibPath extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** pk */
    private Long pathId;

    /** 资源路径 */
    @Excel(name = "资源路径")
    private String dataPath;

    /** 增加时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "增加时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date addTime;

    /** 状态，0可用，1维护，2关闭 */
    @Excel(name = "状态，0可用，1维护，2关闭")
    private String status;

    /** 资源名称 */
    @Excel(name = "资源名称")
    private String dataName;

    public void setPathId(Long pathId) 
    {
        this.pathId = pathId;
    }

    public Long getPathId() 
    {
        return pathId;
    }
    public void setDataPath(String dataPath) 
    {
        this.dataPath = dataPath;
    }

    public String getDataPath() 
    {
        return dataPath;
    }
    public void setAddTime(Date addTime) 
    {
        this.addTime = addTime;
    }

    public Date getAddTime() 
    {
        return addTime;
    }
    public void setStatus(String status) 
    {
        this.status = status;
    }

    public String getStatus() 
    {
        return status;
    }
    public void setDataName(String dataName) 
    {
        this.dataName = dataName;
    }

    public String getDataName() 
    {
        return dataName;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("pathId", getPathId())
            .append("dataPath", getDataPath())
            .append("addTime", getAddTime())
            .append("updateTime", getUpdateTime())
            .append("status", getStatus())
            .append("dataName", getDataName())
            .toString();
    }
}
