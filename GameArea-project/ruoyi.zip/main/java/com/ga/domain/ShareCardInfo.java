package com.ga.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 资源站帖子信息对象 share_card_info
 * 
 * @author wws
 * @date 2023-04-13
 */
public class ShareCardInfo extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** pk */
    private Long infoId;

    /** 关联资源帖子id */
    @Excel(name = "关联资源帖子id")
    private String cardId;

    /** 帖子页面内容 */
    @Excel(name = "帖子页面内容")
    private String message;

    /** 资源信息 */
    @Excel(name = "资源信息")
    private String sourceInfo;

    /** 资源相关地址 */
    @Excel(name = "资源相关地址")
    private String sourceLink;

    public void setInfoId(Long infoId) 
    {
        this.infoId = infoId;
    }

    public Long getInfoId() 
    {
        return infoId;
    }
    public void setCardId(String cardId) 
    {
        this.cardId = cardId;
    }

    public String getCardId() 
    {
        return cardId;
    }
    public void setMessage(String message) 
    {
        this.message = message;
    }

    public String getMessage() 
    {
        return message;
    }
    public void setSourceInfo(String sourceInfo) 
    {
        this.sourceInfo = sourceInfo;
    }

    public String getSourceInfo() 
    {
        return sourceInfo;
    }
    public void setSourceLink(String sourceLink) 
    {
        this.sourceLink = sourceLink;
    }

    public String getSourceLink() 
    {
        return sourceLink;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("infoId", getInfoId())
            .append("cardId", getCardId())
            .append("message", getMessage())
            .append("sourceInfo", getSourceInfo())
            .append("sourceLink", getSourceLink())
            .toString();
    }
}
