package com.ga.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 论坛帖子二级回复消息对象 bbs_reply_reply
 * 
 * @author wws
 * @date 2023-04-13
 */
public class BbsReplyReply extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** pk */
    private Long rrId;

    /** 二级回复信息文本 */
    @Excel(name = "二级回复信息文本")
    private String message;

    /** 从属帖子id */
    @Excel(name = "从属帖子id")
    private String cardId;

    /** 上级回复贴id */
    @Excel(name = "上级回复贴id")
    private String replyId;

    /** 回复对象id */
    @Excel(name = "回复对象id")
    private String replyTo;

    /** 状态，0启用，1关闭 */
    @Excel(name = "状态，0启用，1关闭")
    private String status;

    public void setRrId(Long rrId) 
    {
        this.rrId = rrId;
    }

    public Long getRrId() 
    {
        return rrId;
    }
    public void setMessage(String message) 
    {
        this.message = message;
    }

    public String getMessage() 
    {
        return message;
    }
    public void setCardId(String cardId) 
    {
        this.cardId = cardId;
    }

    public String getCardId() 
    {
        return cardId;
    }
    public void setReplyId(String replyId) 
    {
        this.replyId = replyId;
    }

    public String getReplyId() 
    {
        return replyId;
    }
    public void setReplyTo(String replyTo) 
    {
        this.replyTo = replyTo;
    }

    public String getReplyTo() 
    {
        return replyTo;
    }
    public void setStatus(String status) 
    {
        this.status = status;
    }

    public String getStatus() 
    {
        return status;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("rrId", getRrId())
            .append("message", getMessage())
            .append("cardId", getCardId())
            .append("replyId", getReplyId())
            .append("replyTo", getReplyTo())
            .append("createBy", getCreateBy())
            .append("createTime", getCreateTime())
            .append("updateTime", getUpdateTime())
            .append("status", getStatus())
            .toString();
    }
}
