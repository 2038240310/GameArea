package com.ga.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 资源站帖子-标签关联对象 share_card_tag
 * 
 * @author wws
 * @date 2023-04-13
 */
public class ShareCardTag extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** pk */
    private Long relId;

    /** 关联资源帖子id */
    @Excel(name = "关联资源帖子id")
    private String cardId;

    /** 关联标签id */
    @Excel(name = "关联标签id")
    private String tagId;

    /** 状态，0启用，1关闭 */
    @Excel(name = "状态，0启用，1关闭")
    private String status;

    public void setRelId(Long relId) 
    {
        this.relId = relId;
    }

    public Long getRelId() 
    {
        return relId;
    }
    public void setCardId(String cardId) 
    {
        this.cardId = cardId;
    }

    public String getCardId() 
    {
        return cardId;
    }
    public void setTagId(String tagId) 
    {
        this.tagId = tagId;
    }

    public String getTagId() 
    {
        return tagId;
    }
    public void setStatus(String status) 
    {
        this.status = status;
    }

    public String getStatus() 
    {
        return status;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("relId", getRelId())
            .append("cardId", getCardId())
            .append("tagId", getTagId())
            .append("createTime", getCreateTime())
            .append("updateTime", getUpdateTime())
            .append("status", getStatus())
            .toString();
    }
}
